
import tkinter as tk
from tkinter import messagebox
import joblib

# Load the trained model
try:
    model = joblib.load("phishing_detector_logistic_model.pkl")
    print("Model loaded successfully.")
except Exception as e:
    print("Error loading model:", e)
    model = None  # Set model to None if loading fails

# Function to classify email as phishing or legitimate
def detect_phishing():
    if model is None:
        messagebox.showerror("Model Error", "Model failed to load. Please check the model file.")
        return

    email_subject = subject_entry.get().strip()
    email_body = body_entry.get("1.0", "end-1c").strip()

    if not email_subject or not email_body:
        messagebox.showerror("Input Error", "Please enter both the subject and body of the email.")
        return

    # Combine subject and body for prediction
    email_text = email_subject + " " + email_body
    prediction = model.predict([email_text])[0]

    # Show result based on prediction
    if prediction == 1:
        messagebox.showinfo("Result", "The email is Legitimate.")
    else:
        messagebox.showinfo("Result", "The email is Phishing/Spam.")

# Set up the GUI
root = tk.Tk()
root.title("Phishing Email Detector")

# Subject entry
tk.Label(root, text="Enter the email subject:").pack()
subject_entry = tk.Entry(root, width=70)
subject_entry.pack()

# Body entry
tk.Label(root, text="Enter the email body:").pack()
body_entry = tk.Text(root, height=15, width=70)
body_entry.pack()

# Detect button
detect_button = tk.Button(root, text="Detect", command=detect_phishing)
detect_button.pack()

# Run the GUI loop
root.mainloop()
